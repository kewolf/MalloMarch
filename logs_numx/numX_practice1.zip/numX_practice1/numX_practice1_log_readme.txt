Some notes about practice 1 and the logs files from the practice that are in this directory (numX_practice1):

    -- The "setup" folder contains the logs that were gathered as we were setting up the computers
    and getting ready to begin the study

    -- The rest of the log files contain the interactions of the performers during the practice session

    -- Players:
        Player 1: Chris, Thing 1 computer, IP: 192.168.1.6
        Player 2: Josh,  Thing 2 computer, IP: 192.168.1.5
        Player 3: Nikitas, Reids comptuer, IP: 192.168.1.6

    THERE ARE SOME ERRORS IN THE LOG FILES:
        - The "path" value of the message is listed as \left, \middle, \right, however, json is not happy with
        those so it is best to search and replace them with 0, 1, and 2.

        - The Measure Number in MEASR logs is one greater than it should be (due to a bug in the code). A
        soultion would be to subtract one from all of those values

        - The FLPMA messages are a type and should all be converted to FLPME messages (a typo in the code
        labeled the flipping metro on/off as flipping mallo)


    TIMELINE OF PRACTICE:

    -- 10:28am
        They began practicing on their own with the metronome set to 60BPM

        - We initially set it so they could only hear themselves, but some of the performers also set it so they
        could hear the other performers very softly
        - They set the parameters as they liked, but Reid recommended Pitched Percussion with a high sustain

        Initial Feedback from performers:
            P2: Some short strikes give me notes, while some of the medium ones don't.
            P1: Hard to play multiple notes in a row.

    -- 10:33am
        We suggested the players stand up and we raised the mallo sensors to make it more comfortable

    -- 10:35am
        Reid give more directly on how to best trigger the notes ("flicks")

    -- 10:40am
        We force all plalyers to only hear themselves so they can focus on learning to play on there own.

    -- 10:41am
        Pictures were taken

    -- 10:43am
        Reid helps Player 1 debug
            P1: Sounds like the hit is delayed or 2 notes are playing at once".
            Reid: Related to the peformance of the computer. Delays in the machine.

    -- 10:46am
        P2: Is the system using Chuck?
        Reid: No, it uses web audio.

    -- 10:48am
        Ask players how it is going
            Katie: Do you feel successful?
                P1 - Yes. I am tracking into 1 motion and get the hang of it, then try another motion
            Katie: Feel comfortable moving on?
                All: (agree)

    -- 10:49am
        Increase BPM to 80

    -- 10:53am
        How does the new speed feel?
            P2: Easier, 60 was too slow, 80 hides imperfections
            P3: Harder, got on and off the grove
            P1: Same - Latency (confounds? can't read notes...) at higher speed
            P2: More likely to have a hit at faster rate

    -- 10:50am
        P2 goes to the bathrom
        P1 and P3: switch up instrument parameters (from pitched percussion to drum corp / electronic)

    -- 10:58am
        Everyone turns up the other players and change parameters so they can hear themselves all together
        Recommend they choose settings that wil be best for them to be able to synchronize together

    -- 11:01am
        Everyone plays together

    -- 11:03am
        P3 computer begins to slow down and not work well

    -- 11:04am
        We call it quits and we ask players to reflect:
            P2: At 60bpm the delay of the instrument felt more real, which at 80 it was easier to get in the
                "motion groove". I tried to play off the metronom (playing the offbeats)

        Reid: What was the most challenging?
            P1: Finding the right motion and the feel of the dowel. Striking too quickly, you lose track of
            the beat. The dowel is light (weight).

            P2: Time based on hitting sounds (since you aren't physically striking the surface),
            you are the one to stop the mallet

            P3: Need to balance (when to strike?) based on the feedback

            P2: Tried to replicate the bounce-back of striking a real surface, but then it would trigger double
            notes

            P3: Synchronizing with the dowel and approximating? time to switch from down motion to up motion

            P1: Reid's "flick" advice was good.

        What about the sounds of the instruments?
            P2: Liked the Drum Core Instrument - had a high echo, probably would have liked PP with echo turned off
            P1: Found the Pitched Percussion easiest to play, more forgiving

        What about your choices for the sounds of the other performers?
            P1: Gave other players obnoxious sounds and his own really nice
            P2: Gave others Pitched Percussion and himself Drum Core
            P1: It would be nice to have the players pan out

        Suggestions:
            P1: Would be nice to adust the volume of the metronome
            P2: Adjust the samples used for the "click" of the metronome




